package com.example.qrscanner_barcode

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
